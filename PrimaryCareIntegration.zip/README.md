# PDES-Integration
The **Patient Data Extraction Service** (PDES) is a proprietary EMIS specification that is used to "push" data from the emis systems to a given web service endpoint.

The pdes-listener .net core project provides the endpoint.

## Design Contraints
The web api is constrained by the EMIS specification.


## Code

In the solution there are two projects:

- pdes-listener.csproj
- integration.Tests.csproj

## Codebase - pdes-listener

The pdes-listener is a simple web api that listens on a configured port. It accepts application/xml only in line with the EMIS Spec.

|File|Description|
|----|-----------|
|/program.cs|Main program entry point|
|/Controllers/RequestController.cs|Http listener code|
|/appsettings.json|config such as http port|

## Unit tests - integration.Tests

The unit tests are setup using xUnit and can be found in the **integration.Tests** project of the solution.

To execute manually simply run ...
```bash
dotnet test
```

note: currently, the tests aren't part of the .vscode launch.json config.

## Deployment

## Running - Self contained
This is a self contained .net core application. To run 

```bash
c:\..\folder\pdes-listener.exe
```

The exe is simply a wrapper around the pdes-listener.dll

## Deploying to IIS
For production deploying to IIS just requires the pdes-listener and files.

## Configuration

|Item|Description|
|-----|---------|
|logfile location|e.g., c:\logs\pdes-listener.log|
|loglevel|etc|
