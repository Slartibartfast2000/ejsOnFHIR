using VisOleDB_Service;
using Microsoft.Extensions.Hosting;

var builder = Host.CreateApplicationBuilder(args);

// Determine if the application should run as a Windows Service or a Console App
var isService = !(System.Diagnostics.Debugger.IsAttached || args.Contains("--console"));

// Add services to the container
builder.Services.AddHostedService<Worker>();

// Configure the application as a Windows Service if needed
if (isService)
{
    builder.Services.Configure<HostOptions>(opts => opts.ServicesStartConcurrently = false);
    builder.Services.AddWindowsService(options =>
    {
        options.ServiceName = "VisOleDB_Service";
    });
}

// Build and run the host
var host = builder.Build();
await host.RunAsync();
