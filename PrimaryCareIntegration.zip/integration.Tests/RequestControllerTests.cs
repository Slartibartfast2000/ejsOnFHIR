using Xunit;
using Moq;
using Microsoft.Extensions.Logging;
using pdes_listener.Controllers;  // Replace with the correct namespace
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;
using System.Xml.Serialization;
using Microsoft.AspNetCore.Http; // Add this line if it's not present

namespace integration.Tests
{
    public class RequestControllerTests
    {
        private readonly Mock<ILogger<RequestController>> _mockLogger;
        private readonly RequestController _requestController;

        public RequestControllerTests()
        {
            _mockLogger = new Mock<ILogger<RequestController>>();
            _requestController = new RequestController(_mockLogger.Object);
        }

 

        [Fact]
        public void Test1()
        {
            // Create a mock of ILogger<RequestController>
            var mockLogger = new Mock<ILogger<RequestController>>();

            // Pass the mock logger to the RequestController
            var pdesListener = new RequestController(mockLogger.Object);

            // Now you can perform tests
            Assert.NotNull(pdesListener);  // Example test to ensure the controller is not null
        }
        
        [Fact]
        public void Test2()
        {
            // Create a mock of ILogger<RequestController>
            var mockLogger = new Mock<ILogger<RequestController>>();

            // Pass the mock logger to the RequestController
            var pdesListener = new RequestController(mockLogger.Object);

            
            // Now you can perform tests
            Assert.NotNull(pdesListener);  // Example test to ensure the controller is not null
        }
         [Fact]
        public async Task Post_ReturnsBadRequest_WhenXmlIsInvalid()
        {
            // Arrange
            var requestBody = "<InvalidXml"; // Invalid XML content
            var httpContext = new DefaultHttpContext();
            httpContext.Request.Body = GenerateStreamFromString(requestBody);
            _requestController.ControllerContext.HttpContext = httpContext;

            // Act
            var result = await _requestController.Post();

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal("Invalid XML format.", badRequestResult.Value);
         //   _mockLogger.Verify(logger => logger.LogError(It.IsAny<string>(), It.IsAny<object[]>()), Times.Once);
        }

        [Fact]
        public async Task Post_ReturnsXmlContent_WhenXmlIsValid()
        {
            // Arrange
            var pdesRequest = new pdes_listener.PdesRequest
            {
                ConversationId = "test-conversation-id",
                InteractionId = "test-interaction-id",
                MessageId = "test-message-id",
                MessageName = "test-message-name",
                SenderOrganisationGuid = "test-sender-guid",
                RecipientOrganisationGuid = "test-recipient-guid",
                StartTime = DateTime.UtcNow,
                Additional = new pdes_listener.Additional(),
                RelatesTo = "relates-to-info"
            };

            var requestBody = SerializeToXml(pdesRequest); // Serialize valid PdesRequest object to XML
            var httpContext = new DefaultHttpContext();
            httpContext.Request.Body = GenerateStreamFromString(requestBody);
            _requestController.ControllerContext.HttpContext = httpContext;

            // Act
            var result = await _requestController.Post();

            // Assert
            var contentResult = Assert.IsType<ContentResult>(result);
            Assert.Equal("application/xml", contentResult.ContentType);
            Assert.Contains("test-message-id", contentResult.Content); // Check if the response contains expected content
        }

        private Stream GenerateStreamFromString(string value)
        {
            var stream = new MemoryStream();
            var writer = new StreamWriter(stream, Encoding.UTF8);
            writer.Write(value);
            writer.Flush();
            stream.Position = 0;
            return stream;
        }

        private string SerializeToXml<T>(T obj)
        {
            var xmlSerializer = new XmlSerializer(typeof(T));
            using var stringWriter = new StringWriter();
            xmlSerializer.Serialize(stringWriter, obj);
            return stringWriter.ToString();
        }
    }
    
}
