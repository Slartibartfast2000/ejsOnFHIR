﻿using Google.Cloud.PubSub.V1;
using Google.Protobuf;
using System;
using System.Threading.Tasks;

public class Publisher
{
    private const string ProjectId = "ndr-discovery-387213";
    private const string TopicId = @"gw1";

    public static async Task PublishMessageAsync(string message)
       {
        PublisherServiceApiClient publisher = await PublisherServiceApiClient.CreateAsync();
        TopicName topicName = TopicName.FromProjectTopic(ProjectId, TopicId);

        // Create the publish request
        var publishRequest = new PublishRequest
        {
            TopicAsTopicName = topicName,
            Messages =
            {
                new PubsubMessage
                {
                    Data = ByteString.CopyFromUtf8(message)
                    //,
                    //Attributes = { { "key", "value" } }  // Optional: add any attributes if necessary
                }
            }
        };

        // Publish the message
        var response = await publisher.PublishAsync(publishRequest);
        Console.WriteLine($"Published message {response.MessageIds[0]} to {topicName}");
    }

    public static void Main(string[] args)
    {
        // Ensure you have set the environment variable for the service account key
       // Environment.SetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS", "path/to/your/service-account-file.json");

        PublishMessageAsync("Hello, Pub/Sub!").Wait();
    }
}
