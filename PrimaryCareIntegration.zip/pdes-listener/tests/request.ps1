$uri = "http://localhost:80/Request"
$headers = @{ "Content-Type" = "application/xml" }
$xmlBody = @"
<ecm:StringRequest MessageId="1f9a7852-3c66-4d49-8811-7e9930095522"
    ServiceName="emis:pdes:informatica" MessageName="BULK_0001" Source="NoSource"
    xmlns:ecm="http://connect.e-mis.co.uk/model/">
    <ecm:ConversationId>00000000-0000-0000-0000-000000000000</ecm:ConversationId>
    <ecm:InteractionId>00000000-0000-0000-0000-000000000000</ecm:InteractionId>
    <ecm:StartTime>2024-07-16T10:05:36.7911964Z</ecm:StartTime>
    <ecm:Additional>
        <ecm:Item Key="PayloadIsGzipCompressed">True</ecm:Item>
    </ecm:Additional>
    <ecm:RelatesTo>00000000-0000-0000-0000-000000000000</ecm:RelatesTo>
    <ecm:SenderIdentifier>10486494-ef5e-44ae-8d3b-1469beba432d</ecm:SenderIdentifier>
    <ecm:RecipientIdentifier>123</ecm:RecipientIdentifier>
    <ecm:RecipientOrganisationGuid>00000000-0000-0000-0000-000000000000</ecm:RecipientOrganisationGuid>
    <ecm:SenderOrganisationGuid>10486494-ef5e-44ae-8d3b-1469beba432d</ecm:SenderOrganisationGuid>
    <ecm:Payload>Payload</ecm:Payload>
</ecm:StringRequest>
"@

# Send the POST request
Invoke-RestMethod -Uri $uri -Method POST -Headers $headers -Body $xmlBody