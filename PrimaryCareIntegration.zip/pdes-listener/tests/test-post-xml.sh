curl -vX 'POST' \
  'http://localhost:5021/WeatherForecast' \
  -H 'Content-Type: application/xml' \
  -H "Accept: application/xml" \
  -d '<?xml version="1.0" encoding="UTF-8"?>
<WeatherForecast>
  <newForecast>The newForecast field is required.</newForecast>
  <date>2023-09-18</date>
  <temperatureC>25</temperatureC>
  <summary>Warm</summary>
</WeatherForecast>'