curl -X 'POST' \
  'http://localhost:5021/WeatherForecast' \
  -H 'accept: */*' \
  -H 'Content-Type: application/json' \
  -d '{
  "newForecast": "wet",
  "date": "2024-09-19",
  "temperatureC": 5,
  "summary": "warm"
}'