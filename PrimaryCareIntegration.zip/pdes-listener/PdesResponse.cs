using System;
using System.Xml.Serialization;

namespace pdes_listener
{
    [XmlRoot(ElementName = "StringResponse", Namespace = "http://connect.e-mis.co.uk/model/")]
    public class PdesResponse
    {
        [XmlAttribute(AttributeName = "MessageId")]
        public string? MessageId { get; set; }

        [XmlAttribute(AttributeName = "ServiceName")]
        public string? ServiceName { get; set; }

        [XmlAttribute(AttributeName = "MessageName")]
        public string? MessageName { get; set; }

        [XmlAttribute(AttributeName = "EventCode")]
        public string? EventCode { get; set; }

        [XmlAttribute(AttributeName = "InRetry")]
        public bool InRetry { get; set; }

        [XmlAttribute(AttributeName = "Type")]
        public string? Type { get; set; }

        [XmlElement(ElementName = "ConversationId", Namespace = "http://connect.e-mis.co.uk/model/")]
        public string? ConversationId { get; set; }

        [XmlElement(ElementName = "InteractionId", Namespace = "http://connect.e-mis.co.uk/model/")]
        public string? InteractionId { get; set; }

        [XmlElement(ElementName = "StartTime", Namespace = "http://connect.e-mis.co.uk/model/")]
        public DateTime? StartTime { get; set; }

        [XmlElement(ElementName = "Additional", Namespace = "http://connect.e-mis.co.uk/model/")]
        public Additional? Additional { get; set; }

        [XmlElement(ElementName = "RelatesTo", Namespace = "http://connect.e-mis.co.uk/model/")]
        public string? RelatesTo { get; set; }

        [XmlElement(ElementName = "RecipientOrganisationGuid", Namespace = "http://connect.e-mis.co.uk/model/")]
        public string? RecipientOrganisationGuid { get; set; }

        [XmlElement(ElementName = "SenderOrganisationGuid", Namespace = "http://connect.e-mis.co.uk/model/")]
        public string? SenderOrganisationGuid { get; set; }
    }
}
