using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace pdes_listener
{
    [XmlRoot(ElementName = "StringRequest", Namespace = "http://connect.e-mis.co.uk/model/")]
    public class PdesRequest
    {
        [XmlAttribute(AttributeName = "MessageId")]
        public string? MessageId { get; set; }

        [XmlAttribute(AttributeName = "ServiceName")]
        public string? ServiceName { get; set; }

        [XmlAttribute(AttributeName = "MessageName")]
        public string? MessageName { get; set; }

        [XmlAttribute(AttributeName = "Source")]
        public string? Source { get; set; }

        [XmlElement(ElementName = "ConversationId", Namespace = "http://connect.e-mis.co.uk/model/")]
        public string? ConversationId { get; set; }

        [XmlElement(ElementName = "InteractionId", Namespace = "http://connect.e-mis.co.uk/model/")]
        public string? InteractionId { get; set; }

        [XmlElement(ElementName = "StartTime", Namespace = "http://connect.e-mis.co.uk/model/")]
        public DateTime? StartTime { get; set; }

        [XmlElement(ElementName = "Additional", Namespace = "http://connect.e-mis.co.uk/model/")]
        public Additional? Additional { get; set; }

        [XmlElement(ElementName = "RelatesTo", Namespace = "http://connect.e-mis.co.uk/model/")]
        public string? RelatesTo { get; set; }

        [XmlElement(ElementName = "SenderIdentifier", Namespace = "http://connect.e-mis.co.uk/model/")]
        public string? SenderIdentifier { get; set; }

        [XmlElement(ElementName = "RecipientIdentifier", Namespace = "http://connect.e-mis.co.uk/model/")]
        public string? RecipientIdentifier { get; set; }

        [XmlElement(ElementName = "RecipientOrganisationGuid", Namespace = "http://connect.e-mis.co.uk/model/")]
        public string? RecipientOrganisationGuid { get; set; }

        [XmlElement(ElementName = "SenderOrganisationGuid", Namespace = "http://connect.e-mis.co.uk/model/")]
        public string? SenderOrganisationGuid { get; set; }

        [XmlElement(ElementName = "Payload", Namespace = "http://connect.e-mis.co.uk/model/")]
        public string? Payload { get; set; }
    }

    public class Additional
    {
        [XmlElement(ElementName = "Item", Namespace = "http://connect.e-mis.co.uk/model/")]
        public List<Item>? Items { get; set; }
    }

    public class Item
    {
        [XmlAttribute(AttributeName = "Key")]
        public string? Key { get; set; }

        [XmlText]
        public string? Value { get; set; }
    }
}
