using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace pdes_listener.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class RequestController : ControllerBase
    {
        private readonly ILogger<RequestController> _logger;

        public RequestController(ILogger<RequestController> logger)
        {
            _logger = logger;
        }

        [HttpPost(Name = "PdesRequest")]
        public async Task<IActionResult> Post()
        {
            // Enable request body buffering to read the body multiple times
            HttpContext.Request.EnableBuffering();

            // Read the raw body as a string (XML)
            string requestBody;
            using (var reader = new StreamReader(HttpContext.Request.Body, Encoding.UTF8, leaveOpen: true))
            {
                requestBody = await reader.ReadToEndAsync();
            }

            // Reset the request body stream position to allow the next process (e.g., model binding) to read it
            HttpContext.Request.Body.Position = 0;

            // Log the raw request body
            _logger.LogInformation("Raw request body: {RequestBody}", requestBody);

            // Deserialize the body into PdesRequest using XmlSerializer
            PdesRequest pdesRequest;
            try
            {
                var serializer = new XmlSerializer(typeof(PdesRequest));
                using (var stringReader = new StringReader(requestBody))
                {
                    pdesRequest = (PdesRequest)serializer.Deserialize(stringReader);
                }
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogError("Failed to deserialize XML: {Error}", ex.Message);
                return BadRequest("Invalid XML format.");
            }

            _logger.LogInformation("Received new request: {0}, {1}, ", pdesRequest.MessageId, pdesRequest.StartTime);

            try
            {
                // Create the response object (echoing the request, as specified)
                PdesResponse pdesResponse = new PdesResponse
                {
                    ConversationId = pdesRequest.ConversationId,
                    InteractionId = pdesRequest.InteractionId,
                    MessageId = pdesRequest.MessageId,
                    StartTime = DateTime.UtcNow,
                    Additional = pdesRequest.Additional,
                    RelatesTo = pdesRequest.RelatesTo,
                    RecipientOrganisationGuid = pdesRequest.RecipientOrganisationGuid,
                    SenderOrganisationGuid = pdesRequest.SenderOrganisationGuid,
                    EventCode = "0",
                    InRetry = false, // This can be changed as required
                    Type = "Undefined", // Placeholder value
                    ServiceName = "Undefined",
                    MessageName = pdesRequest.MessageName
                };

                // Serialize the response to XML
                var xmlSerializer = new XmlSerializer(typeof(PdesResponse), "http://connect.e-mis.co.uk/model/");
                var namespaces = new XmlSerializerNamespaces();
                namespaces.Add("ecm", "http://connect.e-mis.co.uk/model/");

                using (var stringWriter = new StringWriter())
                {
                    xmlSerializer.Serialize(stringWriter, pdesResponse, namespaces);
                    var xmlString = stringWriter.ToString();
                    return Content(xmlString, "application/xml");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Error: {0}", ex.ToString());

                PdesErrorResponse pdesErrorResponse = new PdesErrorResponse
                {
                    MessageId = Guid.NewGuid().ToString(),
                    ServiceName = "YourServiceName",
                    MessageName = "ErrorMessage",
                    EventCode = "-500",
                    InRetry = false,
                    Type = "Error",
                    ConversationId = "00000000-0000-0000-0000-000000000000",
                    InteractionId = "00000000-0000-0000-0000-000000000000",
                    StartTime = DateTime.UtcNow,
                    Additional = "Additional information",
                    RelatesTo = "00000000-0000-0000-0000-000000000000",
                    RecipientOrganisationGuid = "00000000-0000-0000-0000-000000000000",
                    SenderOrganisationGuid = "00000000-0000-0000-0000-000000000000"
                };

                var xmlError = XmlSerializationHelper.ToXmlString(pdesErrorResponse);
                return Content(xmlError, "application/xml");
            }
        }
    }
}
