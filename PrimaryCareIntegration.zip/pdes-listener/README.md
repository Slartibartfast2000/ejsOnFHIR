# PDES Partner Listener

3 Classes that are used to serialise and deserialise the received request and response


dotnet publish --configuration Release --runtime win-x64 --self-contained true --output ./publish
dotnet publish --configuration Release --runtime win-x64 --self-contained true --output ./publish

Roles


Skills

| Roles                           | Skills                                                                                   |
|----------------------------------|------------------------------------------------------------------------------------------|
| **Software Maintenance Engineer**| - Proficiency in programming languages used in the software                               |
|                                  | - Code versioning (e.g., Git) and debugging skills                                       |
|                                  | - Familiarity with development environments and tools                                    |
|                                  | - Knowledge of software architecture and design patterns                                 |
|                                  | - Understanding of the software's deployment process                                     |
| **Technical Support Specialist** | - Strong problem-solving and troubleshooting skills                                      |
|                                  | - Knowledge of the software's functionality and user interface                           |
|                                  | - Communication skills for explaining technical issues to non-technical users            |
|                                  | - Ability to replicate user-reported bugs and issues                                     |
| **System Administrator**         | - Experience in server management and cloud platforms (e.g., AWS, Azure)                 |
|                                  | - Security protocols and access control management                                       |
|                                  | - Backup, monitoring, and recovery skills                                                |
|                                  | - Knowledge of performance tuning and optimization for running environments              |
| **DevOps Engineer**              | - Automation and continuous integration/continuous delivery (CI/CD) pipeline management  |
|                                  | - Scripting and automation of deployments and monitoring                                 |
|                                  | - Containerization and orchestration (e.g., Docker, Kubernetes)                          |
|                                  | - Collaboration between development and operations teams for smoother releases           |
| **Database Administrator (DBA)** | - Database management, optimization, and backup skills                                   |
|                                  | - SQL proficiency and query optimization                                                 |
|                                  | - Experience with database scaling and performance tuning                                |
|                                  | - Knowledge of database security and access control                                      |
| **Customer Support Engineer**    | - Strong communication and interpersonal skills                                          |
|                                  | - In-depth knowledge of product features and common user challenges                      |
|                                  | - Ability to manage and document customer support tickets                                |
|                                  | - Collaborate with technical teams for issue resolution                                  |

2x Band 7 - Software Maintenance Engineer
