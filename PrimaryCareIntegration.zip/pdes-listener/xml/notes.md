

Action: GW setup listener on port 80 and provide end point to Guru and Suba (in the chat)

EMIS - configure endpoint in test env


Under change control - any changes are tracked. RFC may need to be made.

Test 3 - Organisation ID 25657
 
NACS codes (practices) that exist are W31114, W31115, W31116
 
EMIS CDB 50002, 50003
 
& 50006
 
