using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace pdes_listener
{
    public static class XmlSerializationHelper
    {
        public static string ToXmlString<T>(T obj)
        {
            var serializer = new XmlSerializer(typeof(T));
            using (var stringWriter = new StringWriter())
            {
                using (var xmlWriter = XmlWriter.Create(stringWriter, new XmlWriterSettings { Indent = true }))
                {
                    serializer.Serialize(xmlWriter, obj);
                    return stringWriter.ToString();
                }
            }
        }
    }
}
